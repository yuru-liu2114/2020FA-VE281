#ifndef VE281P1_SORT_HPP
#define VE281P1_SORT_HPP

template<typename T>
void swap(T &item1, T &item2) {
    // swap items, a basic operation for sorting
    T tmp = item1;
    item1 = item2;
    item2 = tmp;
}
template<typename T, typename Compare = std::less<T>()>
void bubble_sort(std::vector<T> &vector, Compare comp = std::less<T>()) {
    for (int i = 1; i < (int) vector.size(); i++) {
        for (int j = 0; j < (int) vector.size() - i; j++) {
            if (comp(vector[j + 1], vector[j]))
                // to ensure stability, use strictly less than: vector[j+1] < vector[j] ( < )
                swap(vector[j], vector[j + 1]);
        }
    }
}
template<typename T, typename Compare = std::less<T>()>
void insertion_sort(std::vector<T> &vector, Compare comp = std::less<T>()) {
    for (int i = 1; i < (int) vector.size(); i++) {
        int j = 0, k = i;
        for (; j < i; j++) {
            if (comp(vector[i], vector[j]))
                // to ensure stability, use strictly less than: if vector[i] < vector[j] ( < )
                break;
        }
        T tmp = vector[i];
        for (; k > j; k--) {
            vector[k] = vector[k - 1];
        }
        vector[j] = tmp;
    }
}
template<typename T, typename Compare = std::less<T>()>
void selection_sort(std::vector<T> &vector, Compare comp = std::less<T>()) {
    for (int i = 0; i < (int) vector.size() - 1; i++) {
        int min_index = i;
        for (int j = i + 1; j < (int) vector.size(); j++) {
            if (comp(vector[j], vector[min_index])) {
                // to ensure stability, use strictly less than: if vector[j] < vector[min_index] ( < )
                min_index = j;
            }
        }
        swap(vector[i], vector[min_index]);
    }
}

template<typename T, typename Compare = std::less<T>()>
void merge(std::vector<T> &vector, int left, int mid, int right, Compare comp = std::less<T>()) {
    std::vector<T> leftvec(mid + 1 - left), rightvec(right - mid);
    for (int index = left; index < mid + 1; index++) leftvec[index - left] = vector[index];
    for (int index = mid + 1; index < right + 1; index++) rightvec[index - mid - 1] = vector[index];
    int l = 0, r = 0, k = left;
    while (l < (int) leftvec.size() && r < (int) rightvec.size()) {
        if (comp(rightvec[r], leftvec[l])) {
            // to ensure stability, use strictly less than: rightvec[r] < leftvec[l] ( < )
            vector[k++] = rightvec[r++];
        } else vector[k++] = leftvec[l++];
    }
    if (l == (int) leftvec.size()) {
        while (r < (int) rightvec.size()) {
            vector[k++] = rightvec[r++];
        }
    } else {
        while (l < (int) leftvec.size()) {
            vector[k++] = leftvec[l++];
        }
    }
}

template<typename T, typename Compare = std::less<T>()>
void merge_sort_helper(std::vector<T> &vector, int left, int right, Compare comp = std::less<T>()) {
    if (left >= right) return; // left, right might be negative, thus use int rather than size_t/unsigned int
    int mid = (left + right) / 2;
    merge_sort_helper(vector, left, mid, comp);
    merge_sort_helper(vector, mid + 1, right, comp);
    merge(vector, left, mid, right, comp);
}

template<typename T, typename Compare = std::less<T>()>
void merge_sort(std::vector<T> &vector, Compare comp = std::less<T>()) {
    merge_sort_helper(vector, 0, (int) vector.size() - 1, comp);
}

template<typename T, typename Compare = std::less<T>()>
int partition_extra(std::vector<T> &vector, int left, int right, Compare comp = std::less<T>()) {
    int pivot_index = (left + right) / 2;
    T pivot = vector[pivot_index];
    std::vector<T> vector1(vector.begin() + left, vector.begin() + right + 1);
    int vecleft = left, vecright = right;
    for (int i = 0; i < right - left + 1; i++) {
        if (comp(vector1[i], pivot)) vector[vecleft++] = vector1[i];
        else if (comp(pivot, vector1[i])) vector[vecright--] = vector1[i];
        else continue; // if i=pivot_index or vector1[i]==pivot,just continue to next iteration
    }
    while (vecleft <= vecright) {
        // if there're gap between vecleft and vecright, should be filled with pivot
        // because these blanks results in either pivot_index or elements equal to pivot
        vector[vecleft++] = pivot;
    }
    // because after iteration, vecleft incremented by 1, thus need to subtract 1
    return vecleft - 1;
}

template<typename T, typename Compare = std::less<T>()>
void quick_sort_extra_helper(std::vector<T> &vector, int left, int right, Compare comp = std::less<T>()) {
    if (left >= right) return;
    int pivot_index = partition_extra(vector, left, right, comp);
    quick_sort_extra_helper(vector, left, pivot_index - 1, comp);
    quick_sort_extra_helper(vector, pivot_index + 1, right, comp);
}

template<typename T, typename Compare = std::less<T>()>
void quick_sort_extra(std::vector<T> &vector, Compare comp = std::less<T>()) {
    quick_sort_extra_helper(vector, 0, (int) vector.size() - 1, comp);
}

template<typename T, typename Compare = std::less<T>()>
int partition_inplace(std::vector<T> &vector, int left, int right, Compare comp = std::less<T>()) {
    int i = left + 1;
    int j = right;
    if (i >= j) {
        if (comp(vector[right], vector[left])) swap(vector[right], vector[left]);
        return left;
    }
    int pivot_index = (left + right) / 2;
    T pivot = vector[pivot_index];
    swap(vector[left], vector[pivot_index]);
    while (i < j) {
        while (i < right && comp(vector[i], pivot)) i++;
        bool less_than = comp(vector[j], pivot);
        // *** needs to consider EQUAL! ***
        // thus use less_than to denote vector[j]<pivot, and use its negation for judgement
        while (j > left && !less_than) j--;
        if (i < j) swap(vector[i], vector[j]);
    }
    if (i > j || (i == j && comp(vector[right], vector[left]))) swap(vector[left], vector[j]);
    return j;
}

template<typename T, typename Compare = std::less<T>()>
void quick_sort_inplace_helper(std::vector<T> &vector, int left, int right, Compare comp = std::less<T>()) {
    if (left >= right) return;
    int pivot_index = partition_inplace(vector, left, right, comp);
    quick_sort_inplace_helper(vector, left, pivot_index - 1, comp);
    quick_sort_inplace_helper(vector, pivot_index + 1, right, comp);
}

template<typename T, typename Compare = std::less<T>()>
void quick_sort_inplace(std::vector<T> &vector, Compare comp = std::less<T>()) {
    quick_sort_extra_helper(vector, 0, (int) vector.size() - 1, comp);
}

#endif