# Bluetooth SPP (Client) - Android application

- Reads paired Bluetooth devices from your Android phone/tablet.
- Connects to chosen Bluetooth device and sends request to Raspberry Pi for voltage value.
- Displays received value and disconnects automatically. Reconnect made if voltage value requested again.
