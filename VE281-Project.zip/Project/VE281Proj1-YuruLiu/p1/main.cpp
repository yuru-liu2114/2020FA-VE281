#include <iostream>
#include <vector>
#include <algorithm>
#include "sort.hpp"
#include <ctime>
#include <random>
#include <chrono>

using namespace std;

int main(){
    vector<double> sort_arr[20];

    for(int inc=10;inc<=50;inc+=5) {
        for(int t=0;t<20;t++){
        const int mysize=inc;
        vector<int> test1(mysize);
        vector<int> test2(mysize);
        vector<int> test3(mysize);
        vector<int> test4(mysize);
        vector<int> test5(mysize);
        vector<int> test6(mysize);
        vector<int> test7(mysize);
        std::random_device rd;
        std::mt19937 mt(rd());
        for (int i = 0; i < test7.size(); i++) {
            int tmp = mt();
            test1[i] = tmp;
            test2[i] = tmp;
            test3[i] = tmp;
            test4[i] = tmp;
            test5[i] = tmp;
            test6[i] = tmp;
            test7[i] = tmp;
        }
        auto start=std::chrono::system_clock::now();
        bubble_sort(test1, std::less<int>());
        auto end=std::chrono::system_clock::now();
        auto duration=std::chrono::duration_cast<std::chrono::microseconds>(end-start);
        sort_arr[t].push_back(double(duration.count())*std::chrono::microseconds::period::num/std::chrono::microseconds::period::den);

        start=std::chrono::system_clock::now();
        insertion_sort(test2, std::less<int>());
        end=std::chrono::system_clock::now();
        duration=std::chrono::duration_cast<std::chrono::microseconds>(end-start);
        sort_arr[t].push_back(double(duration.count())*std::chrono::microseconds::period::num/std::chrono::microseconds::period::den);


        start=std::chrono::system_clock::now();
        selection_sort(test3, std::less<int>());
        end=std::chrono::system_clock::now();
        duration=std::chrono::duration_cast<std::chrono::microseconds>(end-start);
        sort_arr[t].push_back(double(duration.count())*std::chrono::microseconds::period::num/std::chrono::microseconds::period::den);

        start=std::chrono::system_clock::now();
        merge_sort(test4, std::less<int>());
        end=std::chrono::system_clock::now();
        duration=std::chrono::duration_cast<std::chrono::microseconds>(end-start);
        sort_arr[t].push_back(double(duration.count())*std::chrono::microseconds::period::num/std::chrono::microseconds::period::den);

        start=std::chrono::system_clock::now();
        quick_sort_extra(test5, std::less<int>());
        end=std::chrono::system_clock::now();
        duration=std::chrono::duration_cast<std::chrono::microseconds>(end-start);
        sort_arr[t].push_back(double(duration.count())*std::chrono::microseconds::period::num/std::chrono::microseconds::period::den);

        start=std::chrono::system_clock::now();
        quick_sort_inplace(test6, std::less<int>());
        end=std::chrono::system_clock::now();
        duration=std::chrono::duration_cast<std::chrono::microseconds>(end-start);
        sort_arr[t].push_back(double(duration.count())*std::chrono::microseconds::period::num/std::chrono::microseconds::period::den);

        start=std::chrono::system_clock::now();
        std::sort(test7.begin(),test7.end(), std::less<int>());
        end=std::chrono::system_clock::now();
        duration=std::chrono::duration_cast<std::chrono::microseconds>(end-start);
        sort_arr[t].push_back(double(duration.count())*std::chrono::microseconds::period::num/std::chrono::microseconds::period::den);
    }
        double arr[7];
        for(int index=0;index<7;index++){
            double tmp=0;
            for(int loop=0;loop<20;loop++){
                tmp+=sort_arr[loop][index];
            }
            arr[index]=tmp/20;
        }
        //cout<<"size is: "<<inc<<endl;
        for(int index=0;index<7;index++){
            cout<<arr[index]<<endl;
        }
    }

}
