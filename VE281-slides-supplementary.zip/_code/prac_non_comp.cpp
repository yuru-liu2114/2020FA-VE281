#include <iostream>
#include <ctime>
#include <vector>
#include <algorithm>
#include <cstdlib>
using namespace std;
void counting_sort(int* arr,const int n,int exp){
    const int range=10;
    int count[range]={0};
    int arr1[n];
    for(int i=0;i<n;i++) {
        count[(arr[i]/exp)%range]++;
    }
    for(int i=1;i<range;i++) count[i]+=count[i-1];
    for(auto i:count)cout<<i<<" ";
    cout<<endl;
    for(int i=n-1;i>=0;i--){
        arr1[--count[(arr[i]/exp)%range]]=arr[i];
    }
    for(int i=0;i<n;i++) arr[i]=arr1[i];
}
void radix_sort(int* arr,const int n){
    int max=arr[0];
    for(int i=0;i<n;i++) {
        if(arr[i]>max) max=arr[i];
    }
    int exp=1;
    for(;max/exp>0;exp*=10){}
    exp/=10;
    for(int j=1;j<=exp;j*=10) counting_sort(arr,n,j);
}
void bucket_sort(int* arr,const int n){
    const int bucket_num=100;
    const int bucket_size=100;
    vector<int> map[bucket_num];
    for(int i=0;i<n;i++){
        map[arr[i]/bucket_size].push_back(arr[i]);
    }
    for(int i=0;i<bucket_size;i++) {
        std::sort(map[i].begin(),map[i].end());
    }
    int index=0;
    for(const auto& i:map){
        for(auto j:i){
            arr[index++]=j;
        }
    }
}

int main(){
    const int size=30;
    int arr[size];
    const int range=10000;
    srand(time(nullptr));
    for(int & i : arr){
        int tmp=rand()%range;
        i=tmp;
    }
    for(auto i:arr) cout<<i<<" ";
    cout<<endl;
    radix_sort(arr,size);
    for(auto i:arr) cout<<i<<" ";
}