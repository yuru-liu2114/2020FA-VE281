#include <iostream>
#include <time.h>
#include <vector>
#include <algorithm>
#include <stdlib.h>

using namespace std;

void swap(int *arr, int i, int j) {
    int tmp = arr[i];
    arr[i] = arr[j];
    arr[j] = tmp;
}

int partition(int *arr, int left, int right) {
    int i = left + 1, j = right;
    if (i >= j) {
        if (arr[left] > arr[right]) swap(arr, left, right);
        return left;
    }
    int pivot_index = (left+right)/2;
    int pivot = arr[pivot_index];
    swap(arr, left, pivot_index);
    while (i < j) {
        while (i < right && arr[i] < pivot) i++;
        while (j > left && arr[j] >= pivot) j--;
        if (i < j) swap(arr, i, j);
    }
    if (i > j || (i == j && arr[left] > arr[right])) swap(arr, left, j);
    return j;
}

int randomized_sel(int *arr, int n, int i, int base) {
    cout<<"base is "<<base<<" n is: "<<n<<" i is: "<<i<<endl;
    if (n == 1) return arr[0];
    int index = partition(arr, 0, n - 1);
    cout<<"after partition: index is "<<index<<endl;
    for(int i=0;i<n;i++) cout<<arr[i]<<" ";
    cout<<endl;
    if (index == i - 1) return arr[index];
    else if (index > i - 1) return randomized_sel(arr, index, i, base);
    else return randomized_sel(arr + index + 1, n - index - 1, i - index - 1, base );
}

int choose_pivot(int *arr, int n) {
    if(n==1) return arr[0];
    int n_5 = n%5==0?n/5:n/5+1;
        vector<int> v[n_5];
        for (int i = 0; i < n; i++) {
            int outer = i / 5;
            v[outer].push_back(arr[i]);
    }
    for (int i = 0; i < n_5; i++) {
        sort(v[i].begin(), v[i].end());
    }
    int arr1[n_5];
    for (int i = 0; i < n_5; i++) {
        if(v[i].size()<5){
            arr1[i]=v[i][v[i].size()/2];
        }
        else arr1[i]=v[i][2];
    }
    return choose_pivot(arr1,n_5);
}
int partition1(int* arr,int n,int pivot){
    int i=0,j=n-1,index=-1;
    if(i>=j) return pivot==arr[i]?i:j;
    while(i<j){
        while(i<n && arr[i]<pivot) i++;
        while(j>0 && arr[j]>=pivot) j--;
        if(arr[i]==pivot) index=i;
        if(i<j) swap(arr,i,j);
    }
    return j;
}
int Deterministic_sel(int* arr,int n,int ith){
    if(n==1) return arr[0];
    int n_5 = n%5==0?n/5:n/5+1;
    vector<int> v[n_5];
    for (int i = 0; i < n; i++) {
        int outer = i / 5;
        v[outer].push_back(arr[i]);
    }
    for (int i = 0; i < n_5; i++) {
        sort(v[i].begin(), v[i].end());
    }
    int arr1[n_5];
    for (int i = 0; i < n_5; i++) {
            arr1[i]=v[i][v[i].size()/2];
    }
    int pivot=Deterministic_sel(arr1,n_5,n_5/2);
    cout<<"pivot is "<<pivot<<" "<<n<<endl;
    int i=0,j=n-1,index;
    return 0;
}
int main() {
    int arr[] = {2, 3, 1, 0, 11, 9, 7, 5, 8,10,4,6,5,8};
    int size = sizeof(arr) / sizeof(arr[0]);
    cout << randomized_sel(arr, size, 11, 0)<<endl;
    for(auto i:arr)cout<<i<<" ";
    //cout<<choose_pivot(arr,size);
    // cout<<Deterministic_sel(arr,size,9);
    return 0;
}
// n=5,index=3: 1 4 3 5 6 i=4
