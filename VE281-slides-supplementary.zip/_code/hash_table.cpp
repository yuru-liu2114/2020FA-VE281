#include <iostream>
#include <list>
using namespace std;

class single_Hash{
    int num_buckets;
    list<int>* table;
public:
    explicit single_Hash(int num){
        num_buckets=num;
        table=new list<int>[num_buckets];
    }
    int get_id(int key) const{return key%num_buckets;}
    bool findItem(int key);
    void insertItem(int key);
    void deleteItem(int key);
    void displayHash();
};
bool single_Hash::findItem(int key) {
    int index=get_id(key);
    list<int>::iterator iter;
    for(iter=table[index].begin();iter!=table[index].end();++iter){
        if(*iter==key){
            return true;
        }
    }
    return false;
}
void single_Hash::insertItem(int key) {
    if(!findItem(key)){
        int index=get_id(key);
        table[index].push_back(key);
    }
    else{return;}
}
void single_Hash::deleteItem(int key) {
    int index=get_id(key);
    list<int>::iterator iter;
    for(iter=table[index].begin();iter!=table[index].end();++iter){
        if(*iter==key){
            break;
        }
    }
    if(iter!=table[index].end()){
        table[index].erase(iter);
    }
}
void single_Hash::displayHash() {
    for(int i=0;i<num_buckets;++i){
        list<int>::iterator iter;
        cout<<i<<" ";
        for(iter=table[i].begin();iter!=table[i].end();++iter){
            cout<<*iter<<" ";
        }
        cout<<endl;
    }
}
int main(){
    int a[] = {15, 11, 27, 8, 12};
    int n = sizeof(a)/sizeof(a[0]);

    // insert the keys into the hash table
    single_Hash h(7);   // 7 is count of buckets in
    // hash table
    for (int i = 0; i < n; i++)
        h.insertItem(a[i]);

    // delete 12 from hash table
    h.deleteItem(12);

    // display the Hash table
    h.displayHash();

    return 0;
}