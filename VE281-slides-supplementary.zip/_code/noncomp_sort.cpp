#include <iostream>
#include <string.h>
#include <vector>
#include <algorithm>
using namespace std;
template <class T>

void counting_sort(T* arr,int size,int exp){
    int count[10]={0};
    T arr1[size];
    memset(count,0,sizeof(count));
    for(int i=0;i<size;++i){ // O(n)
        count[(arr[i]/exp)%10]++;
    }
    for(int i=1;i<=9;i++){ //O(k)
        count[i]+=count[i-1];
    }
    for(int i=size-1;i>=0;--i){ // O(n)
        arr1[--count[(arr[i]/exp)%10]]=arr[i];
    }
    for(int i=0;i<size;++i){ // 注意：不要自相赋值
        arr[i]=arr1[i];
    }
}
template <class T>
int getMax(const T* arr,int size){
    T maxValue=arr[0];
    for(int i=1;i<size;i++) {
        if(arr[i]>maxValue){
            maxValue=arr[i];
        }
    }
    return maxValue;
}


void radix_sort(int* arr,int size){
    int maxValue=getMax(arr,size);
    for(int i=1;maxValue/i>0;i*=10){
        counting_sort(arr,size,i); // obtain MSB
    }
}

void vector_bucket(int* arr,int size){
    vector<int> v[10];
    for(int k=0;k<size;k++) {
        int exp=1;
        for(exp=1;arr[k]/exp>0;exp*=10){}
        int index=(10*arr[k]/exp)%10; // obtain MSB
        v[index].push_back(arr[k]);
    }
    for(int k=0;k<size;k++) {
        sort(v[k].begin(),v[k].end());
    }
    int index=0;
    for(auto & i : v){
        for(int j : i) {
            arr[index++]=j;
        }
    }

}

int main(){
    int arr[]={10,0,1023,245,34,675,3,2022,534,132,8,670,13,6856,18,6543};
    int size=sizeof(arr)/sizeof(arr[0]);

    radix_sort(arr,size);
    //counting_sort(arr,size,1);
    //vector_bucket(arr,size);
    for(int i=0;i<size;++i){
        cout<<arr[i]<<" ";
    }
}

