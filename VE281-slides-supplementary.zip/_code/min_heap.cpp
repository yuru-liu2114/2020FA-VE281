#include<iostream>
#include<climits>
using namespace std;

// Prototype of a utility function to swap two integers
void swap(int *x, int *y);

// A class for Min Heap
class MinHeap
{
    int *harr; // pointer to array of elements in heap
    int capacity; // maximum possible size of min heap
    int heap_size; // Current number of elements in min heap
public:
    // Constructor
    MinHeap(int capacity);

    // to heapify a subtree with the root at given index
    void MinHeapify(int );

    int parent(int i) { return (i-1)/2; }

    // to get index of left child of node at index i
    int left(int i) { return (2*i + 1); }

    // to get index of right child of node at index i
    int right(int i) { return (2*i + 2); }

    void percolateup(int id);
    void percolatedown(int id);
    // to extract the root which is the minimum element
    int extractMin();

    // Decreases key value of key at index i to new_val
    void decreaseKey(int i, int new_val);

    // Returns the minimum key (key at root) from min heap
    int getMin() { return harr[0]; }

    // Deletes a key stored at index i
    void deleteKey(int i);

    // Inserts a new key 'k'
    void insertKey(int k);
};

// Constructor: Builds a heap from a given array a[] of given size
MinHeap::MinHeap(int cap)
{
    heap_size = 0;
    capacity = cap;
    harr = new int[cap];
    harr[0]=0;
}
void MinHeap::percolatedown(int id) {
    for(int j=2*id;j<=heap_size;j=2*id) {
        if(j<heap_size && harr[j]>harr[j+1]) j++;
        if(harr[j/2]<=harr[j]) break;
        swap(&harr[j],&harr[j/2]);
        id=j;
    }
}
void MinHeap::percolateup(int id) {
    while(id>1 && harr[id]<harr[id/2]) {
        swap(&harr[id],&harr[id/2]);
        id/=2;
    }
}
void MinHeap::insertKey(int k)
{
    if (heap_size == capacity)
    {
        cout << "\nOverflow: Could not insertKey\n";
        return;
    }
    harr[++heap_size]=k;
    percolateup(heap_size);
}
void MinHeap::decreaseKey(int i, int new_val)
{
    harr[i] = new_val;
    percolateup(i);
}
int MinHeap::extractMin()
{
    if (heap_size <= 1)
        return INT_MAX;
    swap(&harr[1],&harr[heap_size--]);
    percolatedown(1);
    return harr[heap_size+1];
}

void MinHeap::deleteKey(int i)
{
    decreaseKey(i, INT_MIN);
    extractMin();
}

// A recursive method to heapify a subtree with the root at given index
// This method assumes that the subtrees are already heapified


// A utility function to swap two elements
void swap(int *x, int *y)
{
    int temp = *x;
    *x = *y;
    *y = temp;
}

// Driver program to test above functions
int main()
{
    MinHeap h(11);
    h.insertKey(3);
    h.insertKey(2);
    h.deleteKey(1);
    h.insertKey(15);
    h.insertKey(5);
    h.insertKey(4);
    h.insertKey(45);
    cout << h.extractMin() << " ";
    cout << h.getMin() << " ";
    h.decreaseKey(2, 1);
    cout << h.getMin();
    return 0;
}

