#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>

using namespace std;

class point {
public:
    int x, y, x0, y0;

    explicit point(int x1 = 0, int y1 = 0, int x2 = 0, int y2 = 0) {
        x = x1;
        y = y1;
        x0 = x2;
        y0 = y2;
    }
};

void swap(point &p1, point &p2) {
    point tmp = p1;
    p1 = p2;
    p2 = tmp;
}

int ccw(const point &p1, const point &p2, const point &p3) {
    return (p2.x - p1.x) * (p3.y - p1.y) - (p2.y - p1.y) * (p3.x - p1.x);
}

double distance(const point &p1, const point &p2) {
    return sqrt(((double) p1.x - (double) p2.x) * ((double) p1.x - (double) p2.x) +
                ((double) p1.y - (double) p2.y) * ((double) p1.y - (double) p2.y));
}

bool compare(const point &p1, const point &p2) {
    point p(p1.x0, p1.y0);
    int ccw_tmp = ccw(p, p1, p2);
    if (ccw_tmp == 0) {
        return distance(p, p1) < distance(p, p2);
    } else return ccw_tmp > 0;
}

bool operator==(const point &p1, const point &p2) {
    return (p1.x == p2.x) && (p1.y == p2.y);
}

void graham_scan(vector<point> &s, point *xset, int num) {
    int index = 0;
    for (int i = 0; i < num; i++) {
        if (xset[i].y < xset[index].y || (xset[i].y == xset[index].y && xset[i].x < xset[index].x)) index = i;
    }
    swap(xset[0], xset[index]);
    point origin = xset[0];
    for(int i=0;i<num;i++) {
        xset[i].x0=origin.x;
        xset[i].y0=origin.y;
    }
    sort(xset + 1, xset + num, compare);
    for (int i = 0; i < num; i++) {
        while (s.size() > 1 && ccw(s[s.size() - 2], s[s.size() - 1], xset[i]) <= 0) s.pop_back();
        auto dest = find(s.begin(), s.end(), xset[i]);
        if (dest == s.end()) s.push_back(xset[i]);
    }
}

int main() {
    int num;
    cin >> num;
    if (num == 0) return 0;
    else {
        auto *xset = new point[num];
        vector<point> s;
        for (int i = 0; i < num; i++) {
            cin >> xset[i].x >> xset[i].y;
        }
        graham_scan(s, xset, num);
        for (auto &i:s) cout << i.x << " " << i.y << endl;
        delete[] xset;
    }
}