#include <iostream>
#include <list>

using namespace std;

struct node {
    int value;
    node *prev;
    node *next;
};

class hashlist {
    int capacity;
    node **table;
public:
    hashlist(int n) {
        capacity = n;
        table = new node *[capacity];
        for (int i = 0; i < capacity; i++) {
            table[i] = nullptr;
        }
    }

    int hashkey(int n) {
        return n % capacity;
    }

    void insert(int n) {
        int key = hashkey(n);
        node *initial = table[key];
        if (initial == nullptr) {
            initial = new node;
            initial->value = n;
            initial->next = nullptr;
            initial->prev = nullptr;
            table[key] = initial;
        } else {
            int count = 0;
            while (initial != nullptr) {
                if (initial->value == n) {
                    return;
                }
                count++;
                initial = initial->next;
            }
            node *iniroot = table[key];
            for (int i = 0; i < count - 1; i++) {
                iniroot = iniroot->next;
            }
            node *newnode = new node;
            newnode->value = n;
            newnode->prev = iniroot;
            newnode->next = nullptr;
            iniroot->next = newnode;
        }
    }
    bool find(int n){
        int key=hashkey(n);
        node* initial=table[key];
        while(initial!= nullptr){
            if(initial->value==n){
                return true;
            }
            initial=initial->next;
        }
        return false;
    }

    void remove(int n){
        int key=hashkey(n);
        node* ini=table[key];
        while(ini!= nullptr) {
            if(ini->value==n){
                node* tmp=ini;
                if(tmp->prev!=nullptr) {
                    tmp->prev->next=tmp->next;
                }
                else{
                    table[key]=tmp->next;
                }
                if(tmp->next!= nullptr) tmp->next->prev=tmp->prev;
                ini= nullptr;
                delete ini;
            }
            if(ini!= nullptr){ini=ini->next;}
        }
    }

    void display() {
        for (int i = 0; i < capacity; i++) {
            node *initial = table[i];
            while (initial != nullptr) {
                cout << initial->value << " ";
                initial = initial->next;
            }
            cout << endl;
        }
    }
};

int main() {
    // 0 5 5
    // 1 6 1 11
    // 2 12 2 7
    // 3 3
    // 9 4 9 24
    int arr[] = {0, 3, 7, 5, 2, 9, 1, 12, 5, 2, 4, 9, 3, 6, 1, 11, 24};
    int size = 17;
    int capacity = 5;
    hashlist h(capacity);
    for (int i = 0; i < size; i++) {
        h.insert(arr[i]);
    }
    h.display();
    h.remove(12);
    h.display();
    h.remove(10);
    h.display();
    h.remove( 9);
    h.display();
}