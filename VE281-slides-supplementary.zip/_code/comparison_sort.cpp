#include <iostream>
#include <time.h>
#include <stdlib.h>

using namespace std;

void swap(int *arr, int i, int j) {
    int tmp = arr[i];
    arr[i] = arr[j];
    arr[j] = tmp;
}

void insertionsort(int *arr, int size) {
    for (int i = 1; i < size; ++i) {
        int j = 0, k = i - 1;
        for (; j < i; ++j) {
            if (arr[j] > arr[i]) { // insures stability
                break;
            }
        }
        int tmp = arr[i];
        for (; k >= j; --k) {
            arr[k + 1] = arr[k];
        }
        arr[j] = tmp;
    }
}

int find_min(int *arr, int start, int end) {
    int index = -1, min = INT16_MAX;
    for (int i = start; i <= end; ++i) {
        if (arr[i] < min) {
            min = arr[i];
            index = i;
        }
    }
    return index;
}

void selectionsort(int *arr, int size) {
    for (int i = 0; i < size - 2; ++i) {
        int index = i;
        for (int j = i + 1; j < size - 1; j++) {
            if (arr[j] < arr[index]) index = j;
        }
        swap(arr, i, index);
    }
}

void bubblesort(int *arr, int size) {
    for (int i = 0; i < size - 1; ++i) {
        for (int j = 0; j < size - 1 - i; ++j) {
            if (arr[j + 1] < arr[j]) {
                int tmp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = tmp;
            }
        }
    }
}

void merge(int *arr, int left, int mid, int right) { //mind: right is included
    int leftarr[mid - left + 1];
    int rightarr[right - mid];
    for (int i = 0; i < mid - left + 1; ++i) {
        leftarr[i] = arr[i + left];
    }
    for (int i = 0; i < right - mid; ++i) {
        rightarr[i] = arr[i + mid + 1];
    }
    int i = 0, j = 0, k = left; // mind: k starts from left, rather than 0
    while (i < mid + 1 - left && j < right - mid) { //mind: stability i<4 j<4
        if (leftarr[i] <= rightarr[j]) {
            arr[k++] = leftarr[i++];
        } else {
            arr[k++] = rightarr[j++];
        }
    }
    if (i == mid + 1 - left) {
        while (j < right - mid) {
            arr[k++] = rightarr[j++];
        }
    } else {
        while (i < mid + 1 - left) {
            arr[k++] = leftarr[i++];
        }
    }
}
void merge_inplace(int *a, int left, int mid, int right) {
    int lstart = left, rstart = mid + 1;
    if (a[mid] <= a[rstart]) return;
    while (lstart <= mid && rstart <= right) {
        if (a[lstart] > a[rstart]) {
            int tmp = a[rstart];
            int index = rstart;
            while (index != lstart) {
                a[index] = a[index - 1];
                index--;
            }
            a[lstart] = tmp;
            for (int k = left; k < right + 1; ++k) {
                cout << a[k] << " ";
            }
            cout << endl;
            rstart++;
            mid++; //?
        }
        lstart++;
    }
}

void mergesort(int *arr, int left, int right) {
    if (left >= right) { return; }
    int mid = left + (-left + right) / 2;
    mergesort(arr, left, mid);
    mergesort(arr, mid + 1, right);
    merge_inplace(arr, left, mid, right);
}

int partition2(int *arr, int left, int right) {
    srand(time(nullptr));
    int index = rand() % (right - left + 1);
    cout << "pivot index " << index + left << endl;
    int pivot = arr[index + left];
    swap(arr, index + left, left);
    cout << "after swap pivot and left: " << endl;
    for (int k = left; k < right + 1; ++k) {
        cout << arr[k] << " ";
    }
    cout << endl;
    int i = left + 1, j = right;
    if (i < j) {
        while (i < j) {
            while (arr[i] < pivot && i < right) i++;
            while (arr[j] >= pivot && j > left) j--;
            if (i < j) {
                swap(arr, i, j);
                cout << "after swap i and j: " << endl;
                for (int k = left; k < right + 1; ++k) {
                    cout << arr[k] << " ";
                }
                cout << endl;
            }
        }
        if (i > j || (i == j && arr[left] > arr[right])) {
            swap(arr, left, j);
            cout << "after swap index and j: " << endl;
            for (int k = left; k < right + 1; ++k) {
                cout << arr[k] << " ";
            }
            cout << endl;
        }
        return j;
    } else return left;
}

int partition1(int *arr, int left, int right) {
    srand(time(NULL));
    int index = rand() % (right - left + 1);
    int pivot = arr[index + left];
    cout << "size " << right - left + 1 << endl;
    cout << index << " " << pivot << " " << index + left << endl;
    swap(arr, index + left, left);
    cout << "after swap pivot and left: " << endl;
    for (int i = left; i < right + 1; ++i) {
        cout << arr[i] << " ";
    }
    cout << endl;
    int i = left + 1, j = right;
    if (i > j) {
        return left;
    }
    while (i < j) {
        while (arr[i] < pivot && i < right) {
            i++;
        }
        while (arr[j] >= pivot && j > left) {
            j--;
        }
        cout << "find i: " << i << " j: " << j << endl;
        if (i < j) {
            swap(arr, i, j);
            cout << "after swap i and j: " << endl;
            for (int i = left; i < right + 1; ++i) {
                cout << arr[i] << " ";
            }
            cout << endl;
        } else {
            cout << "break" << endl;
            break;
        }
    }
    if (i > j || (i == j && arr[left] > arr[right])) {
        swap(arr, j, left);
    }
    cout << "after swap index and j: " << endl;
    for (int i = left; i < right + 1; ++i) {
        cout << arr[i] << " ";
    }
    cout << endl;
    return j;


}

int partition(int *arr, int left, int right) {
    srand(time(NULL));
    int index = rand() % (right - left + 1);
    int pivot = arr[index + left];
    int arr1[right - left + 1];
    int arrleft = left, arrright = right;
    for (int i = 0; i < right - left + 1; ++i) {
        arr1[i] = arr[i + left];
    }
    for (int i = 0; i < right - left + 1; ++i) {
        if (i == index) { continue; }
        if (arr1[i] < pivot) {
            arr[arrleft++] = arr1[i];
        }
        if (arr1[i] > pivot) {
            arr[arrright--] = arr1[i];
        }
    }
    arr[arrleft] = pivot;
    return arrleft;
}

void quicksort(int *arr, int left, int right) {
    if (left >= right) { return; }
    int pivot = partition(arr, left, right);
    quicksort(arr, left, pivot - 1);
    quicksort(arr, pivot + 1, right);
}

bool binarysearch(int *A, int left, int right, int key) {
    int mid = (left + right) / 2;
    if (A[mid] == key) return true;
    if (left >= right) return false;
    if (A[mid] > key) return binarysearch(A, left, mid - 1, key);
    return binarysearch(A, mid + 1, right, key);
}

int main() {
    int arr[] = {2, 1, 6, 9, 12, 0, 7, 4};
    int size = sizeof(arr) / sizeof(arr[0]);
    mergesort(arr, 0, size - 1);
    for (int i = 0; i < size; ++i) {
        cout << arr[i] << " ";
    }

    // cout<<binarysearch(arr,0,size-1,5);

}
// 3 2 1 5 4 6
// 1 2 3 5 4 6