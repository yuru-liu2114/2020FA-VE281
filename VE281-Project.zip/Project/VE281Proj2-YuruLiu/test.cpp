#include <iostream>
#include <vector>
#include <algorithm>
#include <assert.h>
#include "hashtable.hpp"
#include "time.h"
#include <chrono>
//#include "p1.cpp"

using namespace std;
using namespace std::chrono;

int main(){
    HashTable<int, int> hash1;
//    std::pair<int, int> newnode = {1, 10};
   //auto it = hash1.find(1);
    hash1.insert(1, 10);
    hash1.insert(9, 8);
    hash1.insert(8, 8);
    hash1.insert(4, 8);
    hash1.insert(6, 4);
    hash1.insert(10, 4);
    hash1.insert(10, 8);
    hash1.insert(12, 8);
    hash1.insert(537, 267);
    cout<<"hash1: "<<endl;
    hash1.print();
    HashTable<int, int> hash2;
    hash2= hash1;
    cout << "Copy: " << endl;
    hash2.print();
    cout << "Erase: " << endl;
    hash1.erase(537);
    cout << endl;
    hash2.print();
    cout << endl;
    hash1.print();
    cout << "Access: " ;
    cout << hash1[2] << endl;
    cout<<hash1[537]<<endl;
    cout<<hash1[10]<<endl;
    cout<<"look hash1"<<endl;
    hash1.print();
    auto it2 = hash1.find(6);
    hash1.erase(it2);
    cout << "Erase iterator: " << endl;
    hash1.print();

    auto it3 = hash1.find(20);

    hash1.insert(it3, 20, 10);
    cout << "Insert iterator 1: " << endl;
    hash1.print();
    auto it4 = hash1.find(9);
    hash1.insert(it4, 9, 100);
    cout << "Insert iterator 2: " << endl;
    hash1.print();

    cout << endl;
    hash2.print();

    cout << "Contain: " << endl;
    cout << hash1.contains(4) << endl;
    cout << hash1.contains(9) << endl;
    cout<<hash1.contains(537)<<endl;
    cout<<hash1.contains(3)<<endl;




//    for (auto iter = hash1.begin(); iter != hash1.end(); ++iter) {
//        cout << "<" << iter->first << ", " << iter->second << ">" << endl;
//    }

}




