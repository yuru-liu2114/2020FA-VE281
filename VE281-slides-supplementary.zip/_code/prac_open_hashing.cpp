#include <iostream>

using namespace std;

template<typename K, typename V>
class node {
public:
    K key;
    V value;

    node(K key1, V value1) {
        key = key1;
        value = value1;
    }
};

template<typename K, typename V>
class map {
public:
    int capacity;
    int size = 0;
    node<K, V> **table;
    node<K, V> *dummy;

    map(int n) {
        capacity = n;
        table = new node<K, V> *[capacity];
        for (int i = 0; i < capacity; i++) table[i] = nullptr;
        dummy = new node<K, V>(-1, -1);
    }

    int Hashkey(K key) {
        int tmp = key % capacity;
        return tmp >= 0 ? tmp : tmp + capacity;
    }

    int gfuc(K key) {
        int tmp = (7 - key) % 7;
        return tmp >= 0 ? tmp : tmp + 7;
    }

    void insert(K key, V value) {
        int hashindex = Hashkey(key);
        if (size >= capacity) return;
        int i = 0, ini_index = hashindex % capacity;
        while (table[hashindex] != nullptr && table[hashindex]->key != key && table[hashindex]->key != -1) {
            i++;
            hashindex = (hashindex + i * gfuc(key)) % capacity;
            if (hashindex == ini_index) return;
        }
        if (table[hashindex] == nullptr || table[hashindex]->key == -1) {
            size++;
            auto *newnode = new node<K, V>(key, value);
            table[hashindex] = newnode;
        } else if (table[hashindex]->key == key) {
            table[hashindex]->value = value;
        }
    }
    V find(K key) {
        int h=Hashkey(key);
        int g=gfuc(key);
        int ini=h;
        int index=h;
        while((table[index]!=nullptr && table[index]->key!=key) || table[index]==nullptr) {
            index=(index+g)%capacity;
            if(index==ini) return 0;
        }
        if(table[index]==nullptr) return 0;
        return table[index]->value;
    }

    V remove(K key) {
        int h=Hashkey(key);
        int g=gfuc(key);
        int ini=h;
        int index=h;
        while(table[index]==nullptr || (table[index]!=nullptr && table[index]->key!=key)) {
            index=(index+g)%capacity;
            if(index==ini) return 0;
        }
        if(table[index]==nullptr) return 0;
        V tmp_val=table[index]->value;
        table[index]->key=-1;
        table[index]->value=-1;
        return tmp_val;
    }

    void display() {
        for (int i = 0; i < capacity; i++) {
            if (table[i] != nullptr && table[i]->key!=-1) {
                cout << i << " " << table[i]->key << " " << table[i]->value << endl;
            }
        }
    }
};

int main() {
    int arr[] = {4371, 1323, 6173, 4199, 4344, 9679, 1989};
    int capacity = 10;
    map<int, int> m(capacity);
    for (auto i:arr) m.insert(i, i);
    m.display();
    cout<<m.find(1)<<endl;
    cout<<m.find(4344)<<endl;
    cout<<m.remove(4344)<<endl;
    m.display();
    m.insert(67,67);
    m.display();
}