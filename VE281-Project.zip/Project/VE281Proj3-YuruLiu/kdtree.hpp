#include <tuple>
#include <vector>
#include <algorithm>
#include <cassert>
#include <stdexcept>

/**
 * An abstract template base of the KDTree class
 */
template<typename...>
class KDTree;

/**
 * A partial template specialization of the KDTree class
 * The time complexity of functions are based on n and k
 * n is the size of the KDTree
 * k is the number of dimensions
 * @typedef Key         key type
 * @typedef Value       value type
 * @typedef Data        key-value pair
 * @static  KeySize     k (number of dimensions)
 */
template<typename ValueType, typename... KeyTypes>
class KDTree<std::tuple<KeyTypes...>, ValueType> {
public:
    typedef std::tuple<KeyTypes...> Key;
    typedef ValueType Value;
    typedef std::pair<const Key, Value> Data;
    static inline constexpr size_t KeySize = std::tuple_size<Key>::value;
    static_assert(KeySize > 0, "Can not construct KDTree with zero dimension");
protected:
    struct Node {
        Data data;
        Node *parent;
        Node *left = nullptr;
        Node *right = nullptr;

        Node(const Key &key, const Value &value, Node *parent) : data(key, value), parent(parent) {}

        const Key &key() { return data.first; }

        Value &value() { return data.second; }
    };

public:
    /**
     * A bi-directional iterator for the KDTree
     * ! ONLY NEED TO MODIFY increment and decrement !
     */
    class Iterator {
    private:
        KDTree *tree;
        Node *node;

        Iterator(KDTree *tree, Node *node) : tree(tree), node(node) {}

        /**
         * Increment the iterator
         * Time complexity: O(log n)
         */
        void increment() {
            if (node == nullptr) return;
            // if have right subtree, find the left most node
            if (node->right != nullptr) {
                auto leftmost = node->right;
                while (leftmost->left != nullptr) {
                    leftmost = leftmost->left;
                }
                node = leftmost;
                return;
            } else {
                // if right subtree is empty, find first root that has node as its left kid
                auto parentnode = node->parent;
                auto currnode = node;
                while (parentnode != nullptr) {
                    if (parentnode->left == currnode) {
                        node = parentnode;
                        return;
                    } else {
                        currnode = parentnode;
                        parentnode = currnode->parent;
                    }
                }
                // if both not found, set node as nullptr
                node = nullptr;
            }
        }


        /**
         * Decrement the iterator
         * Time complexity: O(log n)
         */
        void decrement() {
            // TODO: implement this function
            if (node == nullptr) return;
            if (node->left != nullptr) {
                // if have left subtree, find the right most node
                auto rightmost = node->left;
                while (rightmost->right != nullptr) {
                    rightmost = rightmost->right;
                }
                node = rightmost;
                return;
            } else {
                // if left subtree is empty, find first root that has node as its right kid
                auto parentnode = node->parent;
                auto currnode = node;
                while (parentnode != nullptr) {
                    if (parentnode->right == currnode) {
                        node = parentnode;
                        return;
                    } else {
                        currnode = parentnode;
                        parentnode = currnode->parent;
                    }
                }
            }
            // if both not found, set node as nullptr
            node = nullptr;
        }

    public:
        friend class KDTree;

        Iterator() = delete;

        Iterator(const Iterator &) = default;

        Iterator &operator=(const Iterator &) = default;

        Iterator &operator++() {
            increment();
            return *this;
        }

        Iterator operator++(int) {
            Iterator temp = *this;
            increment();
            return temp;
        }

        Iterator &operator--() {
            decrement();
            return *this;
        }

        Iterator operator--(int) {
            Iterator temp = *this;
            decrement();
            return temp;
        }

        bool operator==(const Iterator &that) const {
            return node == that.node;
        }

        bool operator!=(const Iterator &that) const {
            return node != that.node;
        }

        Data *operator->() {
            return &(node->data);
        }

        Data &operator*() {
            return node->data;
        }
    };

protected:                      // DO NOT USE private HERE!
    Node *root = nullptr;       // root of the tree
    size_t treeSize = 0;        // size of the tree

    /**
     * Find the node with key
     * Time Complexity: O(k log n)
     * @tparam DIM current dimension of node
     * @param key
     * @param node
     * @return the node with key, or nullptr if not found
     */
    template<size_t DIM>
    Node *find(const Key &key, Node *node) {
        constexpr size_t DIM_NEXT = (DIM + 1) % KeySize;
        // TODO: implement this function
        if (node == nullptr) return nullptr;
        if (node->key() == key) {
            // identical in all dimensions
            return node;
        }
        if (std::get<DIM>(key) > std::get<DIM>(node->key())) {
            // in DIM, key is greater than node->key(), thus search right subtree
            return find<DIM_NEXT>(key, node->right);
        } else { return find<DIM_NEXT>(key, node->left); }
    }

    /**
     * Insert the key-value pair, if the key already exists, replace the value only
     * Time Complexity: O(k log n)
     * @tparam DIM current dimension of node
     * @param key
     * @param value
     * @param node
     * @param parent
     * @return whether insertion took place (return false if the key already exists)
     */
    template<size_t DIM>
    bool insert(const Key &key, const Value &value, Node *&node, Node *parent) {
        constexpr size_t DIM_NEXT = (DIM + 1) % KeySize;
        // TODO: implement this function
        if (node == nullptr) {
            // if not found, add new node, increment treeSize
            node = new Node(key, value, parent);
            treeSize++;
            return true;
        }
        if (node->key() == key) {
            // if found(key==node->key() in all dimensions), update node->value()
            node->value() = value;
            return false;
        }
        if (std::get<DIM>(key) < std::get<DIM>(node->key())) {
            // in DIM, key is less than node->key(), thus search less subtree for insertion
            return insert<DIM_NEXT>(key, value, node->left, node);
        } else {
            return insert<DIM_NEXT>(key, value, node->right, node);
        }
    }

    /**
     * Compare two keys on a dimension
     * Time Complexity: O(1)
     * @tparam DIM comparison dimension
     * @tparam Compare
     * @param a
     * @param b
     * @param compare
     * @return relationship of two keys on a dimension with the compare function
     */
    template<size_t DIM, typename Compare>
    static bool compareKey(const Key &a, const Key &b, Compare compare = Compare()) {
        if (std::get<DIM>(a) != std::get<DIM>(b)) {
            return compare(std::get<DIM>(a), std::get<DIM>(b));
        }
        return compare(a, b);
    }

    /**
     * Compare two nodes on a dimension
     * Time Complexity: O(1)
     * @tparam DIM comparison dimension
     * @tparam Compare
     * @param a
     * @param b
     * @param compare
     * @return the minimum / maximum of two nodes
     */
    template<size_t DIM, typename Compare>
    static Node *compareNode(Node *a, Node *b, Compare compare = Compare()) {
        if (!a) return b;
        if (!b) return a;
        return compareKey<DIM, Compare>(a->key(), b->key(), compare) ? a : b;
    }

    /**
     * Find the minimum node on a dimension
     * Time Complexity: ?
     * @tparam DIM_CMP comparison dimension
     * @tparam DIM current dimension of node
     * @param node
     * @return the minimum node on a dimension
     */
    template<size_t DIM_CMP, size_t DIM>
    Node *findMin(Node *node) {
        constexpr size_t DIM_NEXT = (DIM + 1) % KeySize;
        // TODO: implement this function
        if (node == nullptr) return nullptr;
        Node *minnode, *leftminnode, *rightminnode;
        if (DIM_CMP == DIM) {
            minnode = findMin<DIM_CMP, DIM_NEXT>(node->left);
            // this comparison is to ensure minnode is non-null pointer, at most node
            minnode = compareNode<DIM_CMP, std::less<>>(minnode, node);
        } else {
            // because DIM!=DIM_CMP, cannot decide relation of leftsubtree and rightsubtree, thus need to find both
            leftminnode = findMin<DIM_CMP, DIM_NEXT>(node->left);
            rightminnode = findMin<DIM_CMP, DIM_NEXT>(node->right);
            minnode = compareNode<DIM_CMP, std::less<>>(leftminnode, rightminnode);
            minnode = compareNode<DIM_CMP, std::less<>>(minnode, node);
        }
        return minnode;
    }

    /**
     * Find the maximum node on a dimension
     * Time Complexity: ?
     * @tparam DIM_CMP comparison dimension
     * @tparam DIM current dimension of node
     * @param node
     * @return the maximum node on a dimension
     */
    template<size_t DIM_CMP, size_t DIM>
    Node *findMax(Node *node) {
        constexpr size_t DIM_NEXT = (DIM + 1) % KeySize;
        // TODO: implement this
        if (node == nullptr) return nullptr;
        Node *maxnode, *leftmaxnode, *rightmaxnode;
        if (DIM == DIM_CMP) {
            maxnode = findMax<DIM_CMP, DIM_NEXT>(node->right);
            // this comparison is to ensure maxnode is non-null pointer, at least node
            maxnode = compareNode<DIM_CMP, std::greater<>>(maxnode, node);
        } else {
            // because DIM!=DIM_CMP, cannot decide relation of leftsubtree and rightsubtree, thus need to find both
            leftmaxnode = findMax<DIM_CMP, DIM_NEXT>(node->left);
            rightmaxnode = findMax<DIM_CMP, DIM_NEXT>(node->right);
            maxnode = compareNode<DIM_CMP, std::greater<>>(leftmaxnode, rightmaxnode);
            maxnode = compareNode<DIM_CMP, std::greater<>>(maxnode, node);
        }
        return maxnode;
    }

    template<size_t DIM>
    Node *findMinDynamic(size_t dim) {
        constexpr size_t DIM_NEXT = (DIM + 1) % KeySize;
        if (dim >= KeySize) {
            dim %= KeySize;
        }
        if (dim == DIM) return findMin<DIM, 0>(root);
        return findMinDynamic<DIM_NEXT>(dim);
    }

    template<size_t DIM>
    Node *findMaxDynamic(size_t dim) {
        constexpr size_t DIM_NEXT = (DIM + 1) % KeySize;
        if (dim >= KeySize) {
            dim %= KeySize;
        }
        if (dim == DIM) return findMax<DIM, 0>(root);
        return findMaxDynamic<DIM_NEXT>(dim);
    }

    /**
     * Erase a node with key (check the pseudocode in project description)
     * Time Complexity: max{O(k log n), O(findMin)}
     * @tparam DIM current dimension of node
     * @param node
     * @param key
     * @return nullptr if node is erased, else the (probably) replaced node
     */
    template<size_t DIM>
    Node *erase(Node *node, const Key &key) {
        constexpr size_t DIM_NEXT = (DIM + 1) % KeySize;
        // TODO: implement this function
        if (node == nullptr) return nullptr;
        if (key == node->key()) {
            // if corresponding node is found, execute erase
            if (node->left == nullptr && node->right == nullptr) {
                // if node is leaf
                delete node;
                // 1-kid or 2-kid situation will reduce to leaf situation
                treeSize--;
                node = nullptr;
                return nullptr;
            } else if (node->right != nullptr) {
                // first search right subtree
                Node *rightminnode = findMin<DIM, DIM_NEXT>(node->right);
                const_cast<Key &>(node->key()) = rightminnode->key();
                node->value() = rightminnode->value();
                node->right = erase<DIM_NEXT>(node->right, rightminnode->key());
            } else if (node->left != nullptr) {
                Node *leftmaxnode = findMax<DIM, DIM_NEXT>(node->left);
                const_cast<Key &>(node->key()) = leftmaxnode->key();
                node->value() = leftmaxnode->value();
                node->left = erase<DIM_NEXT>(node->left, leftmaxnode->key());
            }
        } else if (std::get<DIM>(key) < std::get<DIM>(node->key())) {
            node->left = erase<DIM_NEXT>(node->left, key);
        } else {
            node->right = erase<DIM_NEXT>(node->right, key);
        }
        return node;
    }

    template<size_t DIM>
    Node *eraseDynamic(Node *node, size_t dim) {
        constexpr size_t DIM_NEXT = (DIM + 1) % KeySize;
        if (dim >= KeySize) {
            dim %= KeySize;
        }
        if (dim == DIM) return erase<DIM>(node, node->key());
        return eraseDynamic<DIM_NEXT>(node, dim);
    }

    // TODO: define your helper functions here if necessary
    Node *copyfrom_helper(Node *node, Node *parentnode) {
        if (node == nullptr) return nullptr;
        Node *newnode = new Node(node->key(), node->value(), parentnode);
        newnode->left = copyfrom_helper(node->left, newnode);
        newnode->right = copyfrom_helper(node->right, newnode);
        return newnode;
    }

    void destructor_helper(Node *thisnode) {
        if (thisnode == nullptr) return;
        destructor_helper(thisnode->left);
        destructor_helper(thisnode->right);
        delete thisnode;
        thisnode = nullptr;
    }

    template<size_t DIM>
    static bool sort_helper_dim(const std::pair<Key, Value> &data1, const std::pair<Key, Value> &data2) {
        return std::get<DIM>(data1.first) < std::get<DIM>(data2.first);
    }

    static bool unique_helper(const std::pair<Key, Value> &data1, const std::pair<Key, Value> &data2) {
        return data1.first == data2.first;
    }

    static bool sort_helper(const std::pair<Key, Value> &data1, const std::pair<Key, Value> &data2) {
        return data1.first < data2.first;
    }

    template<size_t DIM>
    Node *initialKDTree(std::vector<std::pair<Key, Value>> &v, Node *parentnode) {
        constexpr size_t DIM_NEXT = (DIM + 1) % KeySize;
        if (v.size() == 0) return nullptr;
        // left element when size is even number
        size_t mid = v.size() % 2 == 0 ? v.size() / 2 - 1 : v.size() / 2;
        // fetch mediandata
        std::nth_element(v.begin(), v.begin() + mid, v.end(), sort_helper_dim<DIM>);
        std::pair<Key, Value> mediandata = v[mid];
        // divide vector
        std::vector<std::pair<Key, Value>> leftsubvector(v.begin(), v.begin() + mid);
        std::vector<std::pair<Key, Value>> rightsubvector(v.begin() + mid + 1, v.end());
        // construct base node
        auto node = new Node(mediandata.first, mediandata.second, parentnode);
        // construct left and right kids
        node->left = initialKDTree<DIM_NEXT>(leftsubvector, node);
        node->right = initialKDTree<DIM_NEXT>(rightsubvector, node);
        return node;
    }

    static Node *&findLeftMost(Node *&thisnode) {
        if (thisnode->left == nullptr) {
            return findLeftMost(thisnode->left);
        }
        return thisnode;
    }

public:
    KDTree() = default;

    /**
     * Time complexity: O(kn log n)
     * @param v we pass by value here because v need to be modified
     */
    explicit KDTree(std::vector<std::pair<Key, Value>> v) {
        // TODO: implement this function
        treeSize = v.size();
        // first form a unique vector
        // stable sort
        std::stable_sort(v.begin(), v.end(), sort_helper);
        // return end iterator points to the end unique pos(reverse, thus first)
        auto unique_end_pos = std::unique(v.rbegin(), v.rend(), unique_helper);
        // erase duplicated elements
        v.erase(v.begin(), unique_end_pos.base());
        root = initialKDTree<0>(v, nullptr);
    }

    /**
     * Time complexity: O(n)
     */
    KDTree(const KDTree &that) {
        // TODO: implement this function
        this->root = copyfrom_helper(that.root, nullptr);
        this->treeSize = that.treeSize;
    }

    /**
     * Time complexity: O(n)
     */
    KDTree &operator=(const KDTree &that) {
        // TODO: implement this function
        if (this == &that) return *this;
        destructor_helper(this->root);
        this->root = copyfrom_helper(that.root, nullptr);
        this->treeSize = that.treeSize;
        return *this;
    }

    /**
     * Time complexity: O(n)
     */
    ~KDTree() {
        // TODO: implement this function
        destructor_helper(this->root);
    }

    Iterator begin() {
        if (!root) return end();
        auto node = root;
        while (node->left) node = node->left;
        return Iterator(this, node);
    }

    Iterator end() {
        return Iterator(this, nullptr);
    }

    Iterator find(const Key &key) {
        return Iterator(this, find<0>(key, root));
    }

    void insert(const Key &key, const Value &value) {
        insert<0>(key, value, root, nullptr);
    }

    template<size_t DIM>
    Iterator findMin() {
        return Iterator(this, findMin<DIM, 0>(root));
    }

    Iterator findMin(size_t dim) {
        return Iterator(this, findMinDynamic<0>(dim));
    }

    template<size_t DIM>
    Iterator findMax() {
        return Iterator(this, findMax<DIM, 0>(root));
    }

    Iterator findMax(size_t dim) {
        return Iterator(this, findMaxDynamic<0>(dim));
    }

    bool erase(const Key &key) {
        auto prevSize = treeSize;
        erase<0>(root, key);
        return prevSize > treeSize;
    }

    Iterator erase(Iterator it) {
        if (it == end()) return it;
        auto node = it.node;
        if (!it.node->left && !it.node->right) {
            it.node = it.node->parent;
        }
        size_t depth = 0;
        auto temp = node->parent;
        while (temp) {
            temp = temp->parent;
            ++depth;
        }
        eraseDynamic<0>(node, depth % KeySize);
        return it;
    }

    size_t size() const { return treeSize; }
};
