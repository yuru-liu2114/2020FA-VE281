#include <iostream>
#include <bits/stdc++.h>
using namespace std;

struct node{
    int key;
    int count=0;
    struct node *left,*right;
};
struct node* NewNode(int item){
    auto* newnode= new node;
    newnode->key=item;
    newnode->count=1;
    newnode->left=newnode->right=nullptr;
    return newnode;
}
struct node* insert(struct node* thisnode,int item,int& ma){
    if(thisnode== nullptr){
        return NewNode(item);
    }
    if(item<thisnode->key){
        thisnode->left=insert(thisnode->left,item,ma);
    }
    else if(item>thisnode->key){
        thisnode->right=insert(thisnode->right,item,ma);
    }
    else
        thisnode->count++;
    ma=max(thisnode->count,ma);
    return thisnode;
}
void inorder_tra(struct node* root,int size){
    if(root== nullptr) {
        return;
    }
    inorder_tra(root->left,size);
    if(root->count>=size/2+1){
        cout<<root->key;
    }
    inorder_tra(root->right,size);
    delete root;
}


void find_majority_map(int* arr,int size){
    unordered_map<int,int> m;
    for(int i=0;i<size;++i){
        m[arr[i]]++;
    }
    int count=0;
    for(auto i:m){
        if(i.second>=size/2+1){
            count=1;
            cout<<i.first<<endl;
            break;
        }
    }
    if(count==0){
        cout<<"no"<<endl;
    }
}

int main(){
    int arr[]={4,4,1,4,2,3,1,4,4,4};
    int size=sizeof(arr)/sizeof(arr[0]);
    struct node* root= nullptr;
    int ma=0;
    //find_majority_map(arr,size);
    for(int i=0;i<size;++i){
        root=insert(root,arr[i],ma);
    }
    inorder_tra(root,size);
    return 0;
}