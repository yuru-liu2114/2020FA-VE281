#include <iostream>
using namespace std;

void swap(int* arr,int i,int j){
    int tmp=arr[i];
    arr[i]=arr[j];
    arr[j]=tmp;
}
void merge(int* arr,int left,int mid,int right){
     int i=left,j=mid+1;
     while(i<right){
         cout<<"i "<<i<<" j "<<j<<" arr[i] "<<arr[i]<<" arr[j] "<<arr[j]<<endl;
         if(i<=j) {
             if (arr[i] > arr[j]) {
                 swap(arr, i, j);
             }
             i++;
         }
         if(i>j) {
             if(arr[i]<=arr[j]){
                 swap(arr,i,j);
             }
             j=i+1;
         }

     }
}
int main(){
    int arr[9]={1,2,4,6,7,3,4,8,9};
    merge(arr,0,4,8);
    for(int i : arr){
        cout<<i<<" ";
    }
    return 0;
}
