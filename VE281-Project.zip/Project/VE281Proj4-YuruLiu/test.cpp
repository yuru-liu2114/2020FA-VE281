#include <iostream>
#include <vector>
#include <list>
#include <sstream>
#include <queue>
#include <set>
#include <stack>
#include <climits>

struct Vex;

struct Edge {
    int weight;
    Vex *start;
    Vex *end;
};

struct Vex {
    int ID = 0;
    int degree = 0;
    int dist = INT_MAX;
    int distMST = INT_MAX;
    bool isReached = false;
    bool isTraverse = false;
    std::list<Edge *> adjList;
    std::list<Edge *> adjListAll;
};

struct Graph {
    unsigned long VexNum;
    std::vector<Vex> allVex;
};

struct cmpPath {
    bool operator()(const Vex *k1, const Vex *k2) const noexcept {
        if (k1->dist == k2->dist)
            return k1->ID < k2->ID;
        else return k1->dist < k2->dist;
    }
};

struct cmpMST {
    bool operator()(const Vex *k1, const Vex *k2) const noexcept {
        if (k1->distMST == k2->distMST)
            return k1->ID < k2->ID;
        else return k1->distMST < k2->distMST;
    }
};

int main() {
    using namespace std;

    Graph G = {0};

    unsigned long VexNum;
    int sourceID, destID, startID, endID, weight;
    string line;
    stringstream ss;

    cin >> VexNum >> sourceID >> destID;
    G.VexNum = VexNum;
    G.allVex.insert(G.allVex.end(), VexNum, Vex());
    for (auto i = 0; i < VexNum; i++) {
        G.allVex[i].ID = i;
    }

    getline(cin, line);

    while (!cin.eof()) {
        getline(cin, line);
        if (line.empty()) break;
        ss.clear();
        ss.str(line);
        ss >> startID >> endID >> weight;
        auto newEdge = new Edge;
        auto undirectedEdge = new Edge;
        auto undirectedEdgeReverse = new Edge;
        newEdge->weight = weight;
        newEdge->start = &(G.allVex[startID]);
        newEdge->end = &(G.allVex[endID]);
        undirectedEdge->weight = weight;
        undirectedEdge->start = &(G.allVex[startID]);
        undirectedEdge->end = &(G.allVex[endID]);
        undirectedEdgeReverse->weight = weight;
        undirectedEdgeReverse->start = &(G.allVex[endID]);
        undirectedEdgeReverse->end = &(G.allVex[startID]);
        G.allVex[endID].degree++;
        G.allVex[startID].adjList.push_back(newEdge);
        G.allVex[startID].adjListAll.push_back(undirectedEdge);
        G.allVex[endID].adjListAll.push_back(undirectedEdgeReverse);
    }

    //Shortest Path

    std::set<Vex *, cmpPath> Path;

    G.allVex[sourceID].dist = 0;
    for (auto i = 0; i < VexNum; i++)
        Path.emplace(&G.allVex[i]);

    while (!Path.empty()) {
        auto it = Path.begin();
        auto u = *it;
        Path.erase(it);
        for (auto v = u->adjList.begin(); v != u->adjList.end(); ++v) {
            auto alt = INT_MAX;
            if (u->dist != INT_MAX)
                alt = u->dist + (*v)->weight;
            if (alt < (*v)->end->dist) {
                Path.erase((*v)->end);
                (*v)->end->dist = alt;
                Path.emplace((*v)->end);
            }
        }
    }
    if (G.allVex[destID].dist != INT_MAX)
        cout << "Shortest path length is " << G.allVex[destID].dist << endl;
    else
        cout << "No path exists!" << endl;

    //DAG

    stack<int> stk;
    vector<int> vec;
    int v;

    for (auto i = 0; i < VexNum; i++)
        if (G.allVex[i].degree == 0) stk.push(i);

    while (!stk.empty()) {
        v = stk.top();
        stk.pop();
        for (auto itDegree = G.allVex[v].adjList.begin(); itDegree != G.allVex[v].adjList.end(); ++itDegree) {
            (*itDegree)->end->degree--;
            if ((*itDegree)->end->degree == 0) stk.push((*itDegree)->end->ID);
        }
        vec.push_back(v);
    }
    if (vec.size() != G.VexNum)
        cout << "The graph is not a DAG" << endl;
    else
        cout << "The graph is a DAG" << endl;

    //MST

    std::set<Vex *, cmpMST> MST;
    int weightSum = 0;
    bool isReachedAll = true;

    G.allVex[0].distMST = 0;
    G.allVex[0].isTraverse = true;
    MST.emplace(&G.allVex[0]);

    while (!MST.empty()) {
        auto it = MST.begin();
        auto u = (*it);
        u->isReached = true;
        weightSum += u->distMST;
        MST.erase(it);
        for (auto itList = u->adjListAll.begin(); itList != u->adjListAll.end(); ++itList) {
            if ((*itList)->end->isReached) continue;
            if (!(*itList)->end->isTraverse)
                (*itList)->end->isTraverse = true;
            else
                MST.erase((*itList)->end);
            if ((*itList)->end->distMST > (*itList)->weight)
                (*itList)->end->distMST = (*itList)->weight;
            MST.emplace((*itList)->end);
        }
    }

    for (int i = 0; i < VexNum; i++)
        if (!G.allVex[i].isReached) isReachedAll = false;

    if (isReachedAll)
        cout << "The total weight of MST is " << weightSum << endl;
    else
        cout << "No MST exists!" << endl;

    return 0;
}
