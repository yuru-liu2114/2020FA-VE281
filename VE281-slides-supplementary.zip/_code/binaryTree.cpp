#include "binaryTree.h"
#include <iostream>
#include <vector>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <string>

using namespace std;

/* ================================== Node =================================== */
Node::Node(const std::string &str, int num, Node *left, Node *right) {
    // TODO: implement this function.
    this->str=str;
    this->num=num;
    this->left=left;
    this->right=right;
}

Node* Node::leftSubtree() const{
    return left;
}

Node* Node::rightSubtree() const{
    return right;
}

string Node::getstr() const {
    return str;
}

int Node::getnum() const {
    return num;
}

Node *Node::mergeNodes(Node *leftNode, Node *rightNode) {
    // note: newnode should be dynamically allocated
    Node *newnode=new Node(leftNode->str+rightNode->str,leftNode->num+rightNode->num,leftNode,rightNode);
    return newnode;
}
void Node::setleft(Node *n){
    this->left=n;
}
void Node::setright(Node *n) {
    this->right=n;
}
void Node::incnum() {
    num++;
}
/* =============================== Binary Tree =============================== */
int find_depth_helper(Node* node);
// REQUIRES: node is valid pointer
// MODIFIES: int depth
// EFFECTS: return depth from node
bool findpath_helper(const string &s, Node* node,string result,string &finalstr,const int depth);
// REQUIRES: node is valid pointer, depth > 0
// MODIFIES: string finalstr
// EFFECTS: return true if string s exists
void recur_destroy(Node* node);
// REQUIRES: node is valid pointer
// MODIFIES: this
// EFFECTS: recursively delete node
void preorder_helper(Node* node);
// REQUIRES: node is valid pointer
// MODIFIES: this
// EFFECTS: print tree in pre-order
void inorder_helper(Node* node);
// REQUIRES: node is valid pointer
// MODIFIES: this
// EFFECTS: print tree in in-order
void postorder_helper(Node* node);
// REQUIRES: node is valid pointer
// MODIFIES: this
// EFFECTS: print tree in post-order
int findsum_helper(Node* node);
// REQUIRES: node is valid pointer
// MODIFIES: int sum
// EFFECTS: calculate sum according to node
void findeverypath_helper(Node* node,int sum,vector<int>* sumvec);
// REQUIRES: node is valid pointer
// MODIFIES: sumvec
// EFFECTS: add sum of each routine to sumvec
bool covered_helper(Node* thistree,Node* tree);
// REQUIRES: tree and thistree are valid pointers
// MODIFIES: bool return value
// EFFECTS: return true if thistree is covered by tree
bool if_contained(Node* mytree,Node* tree);
// REQUIRES: tree and mytree are valid pointers
// MODIFIES: bool return value
// EFFECTS: return true if mytree is contained by tree
Node* copytree_helper(Node* node);
// REQUIRES: node is valid pointer
// MODIFIES: node pointer
// EFFECTS: return copy of pointer node


BinaryTree::BinaryTree(Node *rootNode){
    // TODO: implement this function.
    if(rootNode!= nullptr){
        root=rootNode;}
}
void recur_destroy(Node* node) {
    if(node== nullptr){return;}
    recur_destroy(node->leftSubtree());
    recur_destroy(node->rightSubtree());
    delete node;
}
BinaryTree::~BinaryTree(){
    recur_destroy(root);
}
int find_depth_helper(Node* node){
    if (node== nullptr) {return 0;}
    return 1+max(find_depth_helper(node->leftSubtree()),find_depth_helper(node->rightSubtree()));
}
int BinaryTree::depth() const {
    return find_depth_helper(root);
}
bool findpath_helper(const string &s, Node* node,string result,string &finalstr,const int depth){
    if (node->getstr()==s){
        finalstr=result;
        return true;}
    if (node->leftSubtree()== nullptr && node->rightSubtree()== nullptr) {return false;}
    if (node->leftSubtree()== nullptr){return findpath_helper(s,node->rightSubtree(),result+"1",finalstr,depth);}
    if (node->rightSubtree()== nullptr) {return findpath_helper(s,node->leftSubtree(),result+"0",finalstr,depth);}
    bool left=findpath_helper(s,node->leftSubtree(),result+"0",finalstr,depth);
    bool right=findpath_helper(s,node->rightSubtree(),result+"1",finalstr,depth);
    return left||right;}
string BinaryTree::findPath(const string &s) const{
    string result,finalstr;
    int depth=this->depth();
    bool flag=findpath_helper(s,root,result,finalstr,depth);
    // don't forget situation: flag=false(s is not found in tree)
    if(!flag){return "-1";}
    return finalstr;
}
void preorder_helper(Node* node){
    if(node==nullptr){return;}
    cout<<node->getnum()<<" ";
    preorder_helper(node->leftSubtree());
    preorder_helper(node->rightSubtree());
}
void BinaryTree::preorder_num() const{
    cout<<endl;
}
void inorder_helper(Node* node){
    if(node==nullptr){return;}
    inorder_helper(node->leftSubtree());
    cout<<node->getstr()<<" ";
    inorder_helper(node->rightSubtree());
}
void BinaryTree::inorder_str() const {
    inorder_helper(root);
    cout<<endl;
}
void postorder_helper(Node* node){
    if(node==nullptr){return;}
    postorder_helper(node->leftSubtree());
    postorder_helper(node->rightSubtree());
    cout<<node->getnum()<<" ";
}
void BinaryTree::postorder_num() const {
    postorder_helper(root);
    cout<<endl;
}
int findsum_helper(Node* node){
    if(node==nullptr){return 0;}
    else{
        return node->getnum()+findsum_helper(node->leftSubtree())+findsum_helper(node->rightSubtree());
    }}
int BinaryTree::sum() const {
    if(root==nullptr) {
        return 0;
    }
    return findsum_helper(root);
}
void findeverypath_helper(Node* node,int sum,vector<int>* sumvec) {
    sum+=node->getnum();
    if(node->leftSubtree()==nullptr && node->rightSubtree()== nullptr) {
        sumvec->push_back(sum);
        return;
    }
    if(node->rightSubtree()!= nullptr){findeverypath_helper(node->rightSubtree(),sum,sumvec);}
    if(node->leftSubtree()!= nullptr) {findeverypath_helper(node->leftSubtree(),sum,sumvec);}
}
bool BinaryTree::allPathSumGreater(int sum) const {
    vector<int>* sumvector = new vector<int>;
    findeverypath_helper(root,0,sumvector);
    for(vector<int>::iterator p=sumvector->begin();p!=sumvector->end();++p) {
        if(*p<=sum) {
            delete sumvector;
            return false;}}
    delete sumvector;
    return true;
}
bool covered_helper(Node* thistree,Node* tree){
    if(thistree== nullptr){return true;}
    if(tree== nullptr || thistree->getnum()!= tree->getnum()){ return false;}
    return covered_helper(thistree->leftSubtree(),tree->leftSubtree()) && covered_helper(thistree->rightSubtree(),tree->rightSubtree());
}
bool BinaryTree::covered_by(const BinaryTree &tree) const {
    return covered_helper(root, tree.root);
}
bool if_contained(Node* mytree,Node* tree){
    if(covered_helper(mytree,tree)){return true;}
    if(tree== nullptr){return false;}
    return (covered_helper(mytree,tree->leftSubtree()) || covered_helper(mytree,tree->rightSubtree()));
    // reuse covered_helper function
}
bool BinaryTree::contained_by(const BinaryTree &tree) const {
    return if_contained(root,tree.root);
}
Node* copytree_helper(Node* node) {
   if(node== nullptr){return nullptr;}
   // recursion
   Node* newroot=new Node(node->getstr(),node->getnum(),copytree_helper(node->leftSubtree()),copytree_helper(node->rightSubtree()));
   return newroot;
}
BinaryTree BinaryTree::copy() const {
    BinaryTree tree(copytree_helper(root));
    return tree;
}
