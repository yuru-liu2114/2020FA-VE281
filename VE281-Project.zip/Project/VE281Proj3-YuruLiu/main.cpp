#include <iostream>
#include "kdtree.hpp"
#include <random>
#include <vector>
    using namespace std;
    typedef std::tuple<int, double, string> Key;
    typedef int Value;
    int main() {
        KDTree<Key, Value> kdt;
        std::vector<std::pair<Key, Value>> data; // used for construct
//    std::vector<std::pair<int, string>> v;
        string str = "a";
        double di = 10.1;
        for (int i = 0; i < 10; i++) {
            str += 'a';
            Key oneKey = make_tuple(i, di, str);
            data.emplace_back(make_pair(oneKey, i));
//        cout << get<0>(oneKey) << " " << get<1>(oneKey) << endl;
//        kdt.insert(oneKey, i);
//        data.emplace_back(make_pair(oneKey, i + 100));
            di += 5.0;
        }
//    shuffle(data.begin(), data.end(), std::mt19937(std::random_device()()));
        KDTree<Key, Value> kdtData(data);
        kdt = kdtData;
        KDTree<Key, Value> newkdt(kdtData);

        kdtData.insert(make_tuple(-1, 50.0, "new"), -1);
        newkdt.insert(make_tuple(-1, 50.0, "new"), -50);
        cout << "erase(1, 15.1, \"aaa\"): " << kdtData.erase(make_tuple(1, 15.1, "aaa")) << endl;
        for (auto &item : kdtData) {
            cout << item.second << endl;
        }
        cout << "--kdt--" << endl;
        for (auto &item : kdt) {
            cout << item.second << endl;
        }
        cout << "--newkdt--" << endl;
        for (auto &item : newkdt) {
            cout << item.second << endl;
        }
        return 0;
    }

