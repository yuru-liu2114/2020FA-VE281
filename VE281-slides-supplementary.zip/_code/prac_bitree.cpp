#include <iostream>

using namespace std;

class Node {
    int value;
    Node *left;
    Node *right;
public:
    Node(int n) {
        value = n;
        left = nullptr;
        right = nullptr;
    }
};

class BinaryTree{
    Node* root;
    BinaryTree() {
        root=new Node(0);
    }
};

