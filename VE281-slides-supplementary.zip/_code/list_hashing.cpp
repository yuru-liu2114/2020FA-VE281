#include <iostream>
#include<bits/stdc++.h>
using namespace std;

class HashList{
    int capacity;
    list<int>* table;
public:
    explicit HashList(int n){
        capacity=n;
        table=new list<int>[n];
    }
    int HashCode(int key) const{
        return key%capacity;
    }
    void insert(int key){
        int HashIndex=HashCode(key);
        auto i=table[HashIndex].begin();
        for(;i!=table[HashIndex].end();i++) {
            if(*i==key){return;}
        }
        table[HashIndex].push_back(key);
    }
    bool find(int key){
        int HashIndex=HashCode(key);
        auto i=table[HashIndex].begin();
        for(;i!=table[HashIndex].end();i++) {
            if(*i==key){return true;}
        }
        return false;
    }
    void deletenode(int key){
        int HashIndex=HashCode(key);
        auto i=table[HashIndex].begin();
        for(;i!=table[HashIndex].end();i++) {
            if(*i==key) break;
        }
        if(i!=table[HashIndex].end()) table[HashIndex].erase(i);
    }
    void display(){
        for(size_t i=0;i<capacity;i++) {
            cout<<i;
            for(auto x:table[i]){
                cout<<" -> "<<x;
            }
            cout<<endl;
        }
    }
};
int main()
{
    // array that contains keys to be mapped
    int a[] = {15, 11, 27, 8, 12};
    int n = sizeof(a)/sizeof(a[0]);

    // insert the keys into the hash table
    HashList h(7);   // 7 is count of buckets in
    // hash table
    for (int i = 0; i < n; i++)
        h.insert(a[i]);
    h.display();
    cout<<h.find(3)<<endl;
    cout<<h.find(12)<<endl;
    // delete 12 from hash table
    h.deletenode(12);

    // display the Hash table
    h.display();

    return 0;
}