#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

struct node{
    int index;
    int value;
};
template <typename T>
void swap(T *arr, int i, int j) {
    T tmp = arr[i];
    arr[i] = arr[j];
    arr[j] = tmp;
}

int partition(int *arr, int left, int right,int given) {
    int i = left + 1, j = right;
    if (i >= j) {
        if (arr[left] > arr[right]) swap(arr, left, right);
        return left;
    }
    int pivot_index = given>=0? given:(left + right) / 2;
    int pivot = arr[pivot_index];
    swap(arr, left, pivot_index);
    while (i < j) {
        while (i < right && arr[i] < pivot) i++;
        while (j > left && arr[j] >= pivot) j--;
        if (i < j) swap(arr, i, j);
    }
    if (i > j || (i == j && arr[right] < arr[left])) swap(arr, left, j);
    return j;
}

int Rselect(int *arr, int n, int i) {
    int rank = i - 1;
    if (n == 1) return arr[0];
    int pivot_index = partition(arr, 0, n - 1,-1);
    if (pivot_index == rank) return arr[pivot_index];
    else if (pivot_index > rank) return Rselect(arr, pivot_index, i);
    else return Rselect(arr + pivot_index + 1, n - pivot_index - 1, i - 1 - pivot_index);
}

bool operator<(node node1,node node2){
    return node1.value<=node2.value;
}
/*
node partition_node(node *arr, int left, int right,int given) {
    int i = left + 1, j = right;
    if (i >= j) {
        if (arr[left].value > arr[right].value) swap(arr, left, right);
        return arr[left];
    }
    int pivot_index = given>=0? given:(left + right) / 2;
    int pivot = arr[pivot_index];
    swap(arr, left, pivot_index);
    while (i < j) {
        while (i < right && arr[i] < pivot) i++;
        while (j > left && arr[j] >= pivot) j--;
        if (i < j) swap(arr, i, j);
    }
    if (i > j || (i == j && arr[right] < arr[left])) swap(arr, left, j);
    return j;
}
 */
node Dselect(node *arr, int n, int i) {
    if (n == 1) return arr[0];
    int n5 = n % 5 == 0 ? n / 5 : n / 5 + 1;
    vector<node> v[n5];
    for (int j = 0; j < n; j++) {
        v[j / 5].push_back(arr[j]);
    }
    for (int j = 0; j < n5; j++) {
        sort(v[j].begin(), v[j].end());
    }
    node arr1[n5];
    for (int j = 0; j < n5; j++) {
        arr1[j] = v[j][v[j].size() / 2];
    }
    node pivot = Dselect(arr1, n5, n5 / 2);
    int arr2[n];
    for(int j=0;j<n;j++){
        arr2[j]=arr[j].value;
    }
    //int pivot_index=partition(arr2,0,n-1,pivot.index);
    int pivot_int=Rselect(arr2,n,i);
    cout<<pivot_int<<endl;
    // 3 4 1 6 9 8 10
    // 0 1 2 3 4 5 6

}


int main() {
    const int size = 17;
    int arr[size] = {0, 3, 7, 5, 2, 9, 1, 12, 5, 2, 4, 9, 3, 6, 1, 11, 24};
    node nodearr[size];
    for(int i=0;i<size;i++){
        node tmp={i,arr[i]};
        nodearr[i]=tmp;
    }
    Dselect(nodearr, size, 3);

}