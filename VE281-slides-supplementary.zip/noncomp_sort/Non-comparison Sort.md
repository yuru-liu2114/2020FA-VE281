# Non-comparison Sort

## Counting Sort

![counting](C:\Users\Lyric\Desktop\VE281\slides\noncomp_sort\counting.png)

## Bucket Sort

![bucket](C:\Users\Lyric\Desktop\VE281\slides\noncomp_sort\bucket.png)

## Radix Sort

![radix](C:\Users\Lyric\Desktop\VE281\slides\noncomp_sort\radix.png)