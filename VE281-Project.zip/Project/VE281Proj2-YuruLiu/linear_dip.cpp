#include <iostream>
using namespace std;

int linear_helper(int a,int b) {
    int mod=a%b;
    if(mod==0) {return b;}
    else return linear_helper(b,mod);
}

int linear(int a,int b) {
    int a1=(a>b)?a:b;
    int b1=(a>b)?b:a;
    return linear_helper(a1,b1);
}


int main() {
    cout<<linear(53,56);
}
