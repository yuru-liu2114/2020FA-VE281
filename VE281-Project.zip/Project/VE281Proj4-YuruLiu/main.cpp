#include <iostream>
#include <assert.h>
#include <vector>
#include <sstream>
#include <queue>
#include <set>

using namespace std;

struct Edge;

struct Node {
    int index = 0;
    int degree = 0;
    int distance = INT16_MAX;
    bool visited = false;
    bool inMST = false;
    vector<Edge *> directed_list;
    vector<Edge *> undirected_list;
};

struct Edge {
    int weight = 0;
    Node *start_node = nullptr;
    Node *end_node = nullptr;
};

struct Graph {
    int node_num;
    vector<Node> all_nodes;
};

struct cmp_Nodes {
    bool operator()(Node *node1, Node *node2) {
        return node1->distance > node2->distance;
    }
};

struct cmp_MST {
    bool operator()(Node *node1, Node *node2) {
        if (node1->distance == node2->distance) {
            return node1->index < node2->index;
        }
        return node1->distance < node2->distance;
    }
};

void construct_edge(Edge *&new_edge, Graph &total_graph, int start_index, int end_index, int weight) {
    new_edge->weight = weight;
    new_edge->end_node = &(total_graph.all_nodes[end_index]);
    new_edge->start_node = &(total_graph.all_nodes[start_index]);
}

int main() {
    int node_num, src_node, dest_node;
    Graph total_graph{};
    cin >> node_num >> src_node >> dest_node;
    assert(node_num > 0);
    assert(src_node >= 0 && src_node < node_num);
    assert(dest_node >= 0 && dest_node < node_num);
    total_graph.node_num = node_num; // VITAL!
    for (int i = 0; i < node_num; i++) {
        Node tmp_node = Node();
        tmp_node.index = i;
        total_graph.all_nodes.insert(total_graph.all_nodes.end(), tmp_node);
    }
    stringstream ss;
    while (!cin.eof()) {
        string line;
        int start_index, end_index, weight;
        getline(cin, line);
        if (line.empty()) {
            continue;
        }
        ss.clear();
        ss.str(line);
        ss >> start_index >> end_index >> weight;
        // directed list: for shortest path
        Edge *new_edge = new Edge;
        construct_edge(new_edge, total_graph, start_index, end_index, weight);
        total_graph.all_nodes[end_index].degree++;
        total_graph.all_nodes[start_index].directed_list.push_back(new_edge);
        // undirected list: for MST
        total_graph.all_nodes[start_index].undirected_list.push_back(new_edge);
        Edge *newrev_edge = new Edge;
        construct_edge(newrev_edge, total_graph, end_index, start_index, weight);
        total_graph.all_nodes[end_index].undirected_list.push_back(newrev_edge);
    }


    // shortest path
    Graph tmp_graph = total_graph;
    tmp_graph.all_nodes[src_node].distance = 0;
    Node tmp_node = tmp_graph.all_nodes[src_node];
    priority_queue<Node *, vector<Node *>, cmp_Nodes> total_queue;
    while (true) {
        tmp_node.visited = true;
        if (tmp_node.index == dest_node) {
            // if reach destination node
            // NOTE: cannot trace back to tmp_graph.all_node because its a copy
            cout << "Shortest path length is " << tmp_node.distance << endl;
            break;
        }
        for (auto iter = tmp_node.directed_list.begin(); iter != tmp_node.directed_list.end(); iter++) {
            (*iter)->start_node->distance = tmp_node.distance; // VITAL!
            if ((*iter)->end_node->distance == INT16_MAX) {
                // if never visited before, add to the queue
                (*iter)->end_node->distance = (*iter)->weight + tmp_node.distance;
                total_queue.push((*iter)->end_node);
            } else if ((*iter)->end_node->distance > (*iter)->weight + tmp_node.distance) {
                // if already visited, update if distance sum gets smaller
                (*iter)->end_node->distance = (*iter)->weight + tmp_node.distance;
            }
        }
        if (total_queue.empty()) {
            // if all connected nodes finish traversal
            cout << "No path exists!" << endl;
            break;
        } else {
            tmp_node = *total_queue.top();
            total_queue.pop();
        }
    }

    // DAG
    tmp_graph = total_graph;
    vector<Node> zeroin_node;
    int zeroin_num = 0;
    for (int i = 0; i < tmp_graph.node_num; i++) {
        if (tmp_graph.all_nodes[i].degree == 0) {
            zeroin_node.push_back(tmp_graph.all_nodes[i]);
        }
    }
    while (!zeroin_node.empty()) {
        tmp_node = zeroin_node.back();
        zeroin_node.pop_back();
        zeroin_num++;
        for (auto &iter : tmp_node.directed_list) {
            if (iter->end_node->degree > 0) {
                iter->end_node->degree--;
            }
            if (iter->end_node->degree == 0) {
                zeroin_node.push_back(*iter->end_node);
            }
        }
    }
    if (zeroin_num == node_num) {
        cout << "The graph is a DAG" << endl;
    } else {
        cout << "The graph is not a DAG" << endl;
    }

    // MST
    tmp_graph = total_graph;
    set<Node *, cmp_MST> total_MST;
    // start with randomly chosen first node
    int total_weight = 0;
    int total_nodes = 0;
    tmp_graph.all_nodes[0].distance = 0;
    tmp_graph.all_nodes[0].inMST = true;
    tmp_graph.all_nodes[0].visited = true;
    total_MST.emplace(&tmp_graph.all_nodes[0]);
    while (!total_MST.empty()) {
        auto curr_index = total_MST.begin();
        auto curr_node = *curr_index;
        // only optimal nodes are in MST
        (*curr_node).inMST = true;
        total_nodes++;
        total_MST.erase(curr_index);
        total_weight += (*curr_node).distance;
        for (auto &iter : (*curr_node).undirected_list) {
            if (iter->end_node->inMST) continue;
            if (!iter->end_node->visited) {
                iter->end_node->visited = true;
            } else {
                // was in MST previously, but not the optimal solution, thus remove it
                total_MST.erase(iter->end_node);
            }
            if (iter->end_node->distance > iter->weight) {
                iter->end_node->distance = iter->weight;
            }
            // add in MST, but not necessarily of the optimal path solution
            total_MST.emplace(iter->end_node);
        }
    }
    if (total_nodes == node_num + 1) {
        cout << "The total weight of MST is " << total_weight << endl;
    } else {
        cout << "No MST exists!" << endl;
    }
    return 0;
}

//3
//0
//1
//0 1 2
//1 0 4
